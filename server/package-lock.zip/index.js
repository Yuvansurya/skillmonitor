const mongoose = require('mongoose');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const User = require('./models/User');

const app = express(); 

const mongoURI = 'mongodb://21f3001741:kzFzRHJtuZwnD2W9@cluster0.uo9iu.mongodb.net/task'

mongoose.connect(mongoURI,{ serverSelectionTimeoutMS: 5000 })
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch(err => {
        console.error('Failed to Connect', err);
    });

app.use(express.json()); // Middleware for parsing JSON
app.use(cookieParser()); // Middleware for parsing cookies
app.use(cors()); // Middleware for handling CORS

const PORT = process.env.PORT || 3000;

app.listen(3000, (err) => {
    if (err) {
        console.error('Failed to start server:', err);
    } else {
        console.log(`Server running on port ${PORT}`);
    }
});
